/*
 * Main.js
 *   
 * This benchmark is modified from the "Touch" demo in Ngcore SDK.
 *
 */

var Core = require('../NGCore/Client/Core').Core;
var GL2 = require('../NGCore/Client/GL2').GL2;
var UI = require('../NGCore/Client/UI').UI;

var Animations = Core.Class.singleton(
	{
		initialize:function () {
			// Construct an object for tank animations. 
			var a = new GL2.Animation();
			// Add frames for the tank animations.

			a.pushFrame(new GL2.Animation.Frame('Content/tank.png', 50, [64, 64], [0.5, 0.5], [0 / 5, 0, 1 / 5, 1]));
			a.pushFrame(new GL2.Animation.Frame('Content/tank.png', 50, [64, 64], [0.5, 0.5], [1 / 5, 0, 1 / 5, 1]));
			a.pushFrame(new GL2.Animation.Frame('Content/tank.png', 50, [64, 64], [0.5, 0.5], [2 / 5, 0, 1 / 5, 1]));
			a.pushFrame(new GL2.Animation.Frame('Content/tank.png', 50, [64, 64], [0.5, 0.5], [3 / 5, 0, 1 / 5, 1]));
			a.pushFrame(new GL2.Animation.Frame('Content/tank.png', 50, [64, 64], [0.5, 0.5], [4 / 5, 0, 1 / 5, 1]));

			this._tank = a;
		},

		getTank:function () {
			return this._tank;
		}
	});

var Background = Core.MessageListener.subclass(
	{
		initialize:function (root) {
			this._background = new GL2.Sprite();
			this._background.setImage('Content/background.png', [1024, 1024]);
			root.addChild(this._background);
		}
	});

var Tank = Core.MessageListener.subclass(
	{
		initialize:function () {
			this._node = new GL2.Sprite();
			this._node.setAnimation(Animations.getTank());
			this._node.setPosition(Math.random() * UI.Window.getWidth(), Math.random() * UI.Window.getHeight());

			if (Math.random() > 0.5)
				this._vx = 0.1;
			else
				this._vx = -0.1;
			if (Math.random() > 0.5)
				this._vy = 0.1;
			else
				this._vy = -0.1;

			// Add listener for tracking frame updates.
			Core.UpdateEmitter.addListener(this, this.onUpdate);
		},

		destroy:function () {
			this._node.destroy();
		},

		setPosition:function (x, y) {
			this._node.setPosition(x, y);
		},

		getNode:function () {
			return this._node;
		},

		onUpdate:function (delta) {

			var p = this._node.getPosition();
			p.setX(p.getX() + this._vx * delta);
			p.setY(p.getY() + this._vy * delta);

			var width = UI.Window.getWidth();
			var height = UI.Window.getHeight();

			if (p.getX() < 0) {
				p.setX(0);
				this._vx = -this._vx;
			}
			if (p.getX() > width) {
				p.setX(width);
				this._vx = -this._vx;
			}
			if (p.getY() < 0) {
				p.setY(0);
				this._vy = -this._vy;
			}
			if (p.getY() > height) {
				p.setY(height);
				this._vy = -this._vy;
			}
			this._node.setPosition(p);
		}
	});

var FPS = Core.MessageListener.singleton(
	{
		initialize:function () {
			this._fpsCount = 0;
			this._deltaCount = 0;
			this._currentFPS = 0;

			this._label = new GL2.Text();
			this._label.setPosition(100, 100);
			this._label.setText('??.??');
			GL2.Root.addChild(this._label);

			Core.UpdateEmitter.addListener(this, this._onUpdate);
		},
		getCurrentFPS:function () {
			return this._currentFPS;
		},
		_onUpdate:function (delta) {
			this._fpsCount++;
			this._deltaCount += delta;
			if (this._deltaCount > 5000) {
				this._currentFPS = this._fpsCount * 1000.0 / this._deltaCount;
				this._label.setText("" + this._currentFPS.toFixed(2));
				this._deltaCount = 0;
				this._fpsCount = 0;
			}
		}
	});

function gameInit() {
	new Background(GL2.Root);

	for (var i = 0; i < 1000; ++i) {
		var b = new Tank();
		GL2.Root.addChild(b.getNode());
	}
}

function main() {
	// initialize and start glview
	var glView = new UI.GLView();
	glView.onload = function () {
		NgLogD("gl view initialized");
		gameInit();
		FPS.initialize();
	};
	glView.setAttribute('frame', [0, 0, UI.Window.getWidth(), UI.Window.getHeight()]);
	glView.setAttribute('active', true);
}
